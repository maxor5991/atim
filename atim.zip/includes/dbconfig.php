<?php
$GLOBALS['dbConfig'] = array(
    'host' => 'localhost',
    'user' => 'root',
    'pass' => '',
    'db' => 'db'
);